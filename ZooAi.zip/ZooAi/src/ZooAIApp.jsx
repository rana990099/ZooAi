import React, { useState, useEffect } from "react";
import AnimalIcon from "./AnimalIcon"; // helper component
import "./styles.css";

const animalList = [
  { name: "Lion", emoji: "🦁" },
  { name: "Tiger", emoji: "🐯" },
  { name: "Monkey", emoji: "🐒" },
  { name: "Fish", emoji: "🐟" },
  { name: "Rabbit", emoji: "🐇" },
  { name: "Peacock", emoji: "🦚" },
  { name: "Pigeon", emoji: "🕊️" },
  { name: "Swello", emoji: "🐦" },
  { name: "Eagle", emoji: "🦅" },
  { name: "Panda", emoji: "🐼" }
];

const ZooAIApp = () => {
  const [predictions, setPredictions] = useState([]);
  const [history, setHistory] = useState([]);

  // Dummy prediction logic (replace with AI later)
  const makePrediction = () => {
    const random = Math.floor(Math.random() * animalList.length);
    return [animalList[random].name];
  };

  const handleBet = () => {
    const pred = makePrediction();
    setPredictions(pred);

    const result = pred[0];
    setHistory((prev) => [...prev.slice(-49), result]);
  };

  return (
    <div className="app-container">
      <h1>Zoo AI Predictor 🧠</h1>

      <button onClick={handleBet}>🎯 Predict</button>

      <div className="prediction-section">
        <h2>Prediction</h2>
        <div className="prediction-grid">
          {predictions.map((name) => {
            const animal = animalList.find((a) => a.name === name);
            return (
              <div key={name} className="animal-box">
                <AnimalIcon name={animal.name} emoji={animal.emoji} size={48} />
                <div className="animal-label">{animal.name}</div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="history-section">
        <h3>Last 50 Bets</h3>
        <div className="history-grid">
          {history.map((name, index) => {
            const animal = animalList.find((a) => a.name === name);
            return (
              <div key={index} className="animal-box-small">
                <AnimalIcon name={animal.name} emoji={animal.emoji} size={28} />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ZooAIApp;