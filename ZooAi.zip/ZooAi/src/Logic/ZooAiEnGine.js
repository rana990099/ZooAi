import * as tf from "@tensorflow/tfjs";

let model;
let history = JSON.parse(localStorage.getItem("zooHistory") || "[]");
let currentInput = [];
let predictionResult = {};

const MAX_HISTORY = 1000;

const createModel = () => {
  model = tf.sequential();
  model.add(tf.layers.lstm({ units: 25, returnSequences: true, inputShape: [5, 9] }));
  model.add(tf.layers.lstm({ units: 50, returnSequences: true }));
  model.add(tf.layers.lstm({ units: 100 }));
  model.add(tf.layers.dense({ units: 9, activation: "softmax" }));
  model.compile({ loss: "categoricalCrossentropy", optimizer: "adam" });
};

const trainModel = async () => {
  const inputs = [];
  const labels = [];
  for (let i = 5; i < history.length; i++) {
    const seq = history.slice(i - 5, i).map(h => oneHot(h.index));
    inputs.push(seq);
    labels.push(oneHot(history[i].index));
  }
  if (inputs.length > 10) {
    await model.fit(tf.tensor3d(inputs), tf.tensor2d(labels), {
      epochs: 8,
      verbose: 0
    });
  }
};

const oneHot = (index) => {
  const arr = Array(9).fill(0);
  arr[index] = 1;
  return arr;
};

export const initZooAI = async () => {
  createModel();
  await trainModel();
};

export const placeBet = async (index) => {
  const multiplier = getMultiplier(index);
  const resultIndex = Math.floor(Math.random() * 9);
  const isWin = resultIndex === index;
  const entry = {
    index,
    resultIndex,
    animal: getAnimal(resultIndex),
    isWin,
    multiplier,
    time: new Date().toLocaleTimeString()
  };
  history.push(entry);
  if (history.length > MAX_HISTORY) history.shift();
  localStorage.setItem("zooHistory", JSON.stringify(history));
  await trainModel();
  return { ...entry, isWin };
};

export const undoBet = () => {
  history.pop();
  localStorage.setItem("zooHistory", JSON.stringify(history));
};

export const resetZooAI = () => {
  history = [];
  localStorage.removeItem("zooHistory");
};

export const getAIStats = () => {
  const total = history.length;
  const wins = history.filter(h => h.isWin).length;
  const losses = total - wins;
  const accuracy = total ? Math.round((wins / total) * 100) : 0;
  const smartness = getSmartness();
  const prediction = getPrediction();
  return {
    total, wins, losses,
    accuracy,
    smartness,
    accuracyClass: accuracy > 65 ? "green" : accuracy > 45 ? "yellow" : "red",
    smartnessClass: smartness > 65 ? "green" : smartness > 45 ? "yellow" : "red",
    prediction: getAnimal(prediction.main),
    top: prediction.top.map(getAnimal)
  };
};

const getPrediction = () => {
  const freq = Array(9).fill(0);
  history.forEach(h => freq[h.index]++);
  const markov = Array(9).fill(0);
  if (history.length > 1) {
    const last = history[history.length - 1].index;
    const nexts = history.filter((_, i) => history[i].index === last && i + 1 < history.length)
                         .map((_, i) => history[i + 1].index);
    nexts.forEach(i => markov[i]++);
  }
  const blended = freq.map((f, i) => f + (markov[i] || 0));
  blended.forEach((v, i) => (blended[i] = v + (Math.random() * 2)));
  const top = [...blended]
    .map((val, idx) => [idx, val])
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4)
    .map(([i]) => i);
  return { main: top[0], top };
};

export const getFishStats = () => {
  const fishWins = history.filter(h => h.index === 8 && h.isWin).length;
  const fishTotal = history.filter(h => h.index === 8).length;
  const chance = fishTotal ? Math.round((fishWins / fishTotal) * 100) : 10;
  const confidence = Math.min(100, fishTotal * 5);
  return { chance, confidence };
};

export const getHistoryData = () => {
  return history.slice(-50).reverse().map(h => ({
    ...h,
    animal: getAnimal(h.index),
  }));
};

export const getHotColdData = () => {
  const freq = Array(9).fill(0);
  history.forEach(h => freq[h.index]++);
  return [...freq]
    .map((val, i) => [i, val])
    .sort((a, b) => b[1] - a[1])
    .map(([i]) => getAnimal(i));
};

export const getStreakStats = () => {
  const streaks = [];
  let current = null;
  history.forEach(h => {
    if (!current || current.type !== (h.isWin ? "W" : "L")) {
      if (current) streaks.push(current);
      current = { type: h.isWin ? "W" : "L", count: 1 };
    } else {
      current.count++;
    }
  });
  if (current) streaks.push(current);
  return streaks.slice(-6).map(s => `${s.type}${s.count}`);
};

export const getRiskLevel = () => {
  const last10 = history.slice(-10);
  const losses = last10.filter(h => !h.isWin).length;
  if (losses >= 7) return "high";
  if (losses >= 4) return "medium";
  return "low";
};

const getAnimal = (i) => [
  "Rabbit", "Swello", "Pigeon", "Peacock", "Monkey", "Panda", "Eagle", "Lion", "Fish"
][i];

const getMultiplier = (i) => [6, 6, 8, 8, 8, 8, 12, 12, 24][i];

const getSmartness = () => {
  let score = 0;
  history.slice(-10).forEach(h => (score += h.isWin ? 1 : -1));
  return Math.max(0, Math.min(100, 50 + score * 10));
};