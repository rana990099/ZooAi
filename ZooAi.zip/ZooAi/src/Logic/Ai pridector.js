// File: src/logic/aiPredictor.js

import * as tf from '@tensorflow/tfjs';

let model;

export async function initModel() { model = tf.sequential(); model.add(tf.layers.lstm({ units: 25, inputShape: [10, 9], returnSequences: true })); model.add(tf.layers.lstm({ units: 50, returnSequences: true })); model.add(tf.layers.lstm({ units: 100 })); model.add(tf.layers.dense({ units: 9, activation: 'softmax' }));

model.compile({ optimizer: 'adam', loss: 'categoricalCrossentropy', metrics: ['accuracy'] }); }

export async function trainModel(history) { if (!model) await initModel();

const inputs = []; const labels = [];

for (let i = 10; i < history.length; i++) { const inputSeq = history.slice(i - 10, i).map(oneHotEncode); const label = oneHotEncode(history[i]); inputs.push(inputSeq); labels.push(label); }

const xs = tf.tensor3d(inputs); const ys = tf.tensor2d(labels);

await model.fit(xs, ys, { epochs: 5, batchSize: 16, shuffle: true }); }

export async function predictNext(history) { if (!model) await initModel(); if (history.length < 10) return Array(9).fill(1 / 9);

const inputSeq = history.slice(-10).map(oneHotEncode); const inputTensor = tf.tensor3d([inputSeq]);

const prediction = model.predict(inputTensor); const result = await prediction.data(); return Array.from(result); }

function oneHotEncode(animalIndex) { const arr = Array(9).fill(0); arr[animalIndex] = 1; return arr; }

