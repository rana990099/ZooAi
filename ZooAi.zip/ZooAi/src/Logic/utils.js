// src/logic/utils.js

export function getRandomAnimal(animals) {
  return animals[Math.floor(Math.random() * animals.length)];
}

export function getLastNItems(array, n) {
  return array.slice(-n);
}

export function calculateStreaks(history) {
  const streaks = {};
  let current = null;
  let count = 0;

  for (let i = 0; i < history.length; i++) {
    const animal = history[i];
    if (animal === current) {
      count++;
    } else {
      if (current) streaks[current] = Math.max(streaks[current] || 0, count);
      current = animal;
      count = 1;
    }
  }

  if (current) streaks[current] = Math.max(streaks[current] || 0, count);
  return streaks;
}

export function calculateFrequency(history) {
  const freq = {};
  history.forEach((animal) => {
    freq[animal] = (freq[animal] || 0) + 1;
  });
  return freq;
}

export function calculateHotAndCold(freq, top = 2) {
  const entries = Object.entries(freq).sort((a, b) => b[1] - a[1]);
  return {
    hot: entries.slice(0, top).map((e) => e[0]),
    cold: entries.slice(-top).map((e) => e[0]),
  };
}