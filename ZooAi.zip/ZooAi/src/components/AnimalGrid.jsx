// src/components/AnimalGrid.jsx
import React from "react";
import AnimalIcon from "./AnimalIcon";

const animals = [
  "lion",
  "panda",
  "fish",
  "monkey",
  "eagle",
  "peacock",
  "rabbit",
  "pigeon",
  "swello"
];

const AnimalGrid = ({ selectedAnimals, onSelect }) => {
  return (
    <div className="animal-grid">
      {animals.map((animal) => (
        <button
          key={animal}
          className={`animal-btn ${selectedAnimals.includes(animal) ? "selected" : ""}`}
          onClick={() => onSelect(animal)}
        >
          <AnimalIcon animal={animal} size={48} />
          <div className="animal-label">{animal}</div>
        </button>
      ))}
    </div>
  );
};

export default AnimalGrid;