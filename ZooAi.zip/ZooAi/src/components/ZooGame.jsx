import React, { useEffect, useState } from "react";
import { initZooAI } from "../logic/zooAIEngine";
import {
  getFishStats,
  getRiskLevel,
  getAIStats,
  getHistoryData,
  getHotColdData,
  getStreakStats,
  placeBet,
  undoBet,
  resetZooAI,
} from "../logic/zooAIEngine";
import "../styles.css";

export default function ZooGame() {
  const [aiData, setAIData] = useState({});
  const [history, setHistory] = useState([]);
  const [hotCold, setHotCold] = useState([]);
  const [streaks, setStreaks] = useState([]);
  const [fish, setFish] = useState({});
  const [lastResult, setLastResult] = useState(null);

  useEffect(() => {
    initZooAI().then(updateAllUI);
  }, []);

  const updateAllUI = async () => {
    setAIData(getAIStats());
    setFish(getFishStats());
    setHistory(getHistoryData());
    setHotCold(getHotColdData());
    setStreaks(getStreakStats());
  };

  const handleBet = async (index) => {
    const result = await placeBet(index);
    setLastResult(result);
    updateAllUI();
  };

  const handleUndo = () => {
    undoBet();
    setLastResult(null);
    updateAllUI();
  };

  const handleReset = () => {
    if (window.confirm("کیا آپ واقعی ری سیٹ کرنا چاہتے ہیں؟")) {
      resetZooAI();
      updateAllUI();
    }
  };

  const animals = [
    { name: "Rabbit", icon: "🐇", multiplier: 6 },
    { name: "Swello", icon: "🐦", multiplier: 6 },
    { name: "Pigeon", icon: "🕊️", multiplier: 8 },
    { name: "Peacock", icon: "🦚", multiplier: 8 },
    { name: "Monkey", icon: "🐒", multiplier: 8 },
    { name: "Panda", icon: "🐼", multiplier: 8 },
    { name: "Eagle", icon: "🦅", multiplier: 12 },
    { name: "Lion", icon: "🦁", multiplier: 12 },
    { name: "Fish", icon: "🐟", multiplier: 24 },
  ];

  return (
    <div>
      <div className="grid">
        {animals.map((a, i) => (
          <button key={i} className="animal" onClick={() => handleBet(i)}>
            <span className="emoji">{a.icon}</span>
            {a.name} <br />
            {a.multiplier}x
          </button>
        ))}
      </div>

      <div className="fish-predictor">
        <h3>Fish Predictor 🐟</h3>
        <p>
          Chance: <span>{fish.chance}%</span> | Confidence:{" "}
          <span>{fish.confidence}%</span>
        </p>
      </div>

      <div className="stats">
        <h3>Prediction Stats</h3>
        <p>
          <strong>AI Prediction:</strong> {aiData.prediction}
        </p>
        <p>
          <strong>Top 4:</strong> {aiData.top?.join(", ")}
        </p>
        <p>
          <strong>Smartness:</strong>{" "}
          <span className={`badge ${aiData.smartnessClass}`}>
            {aiData.smartness}%
          </span>
        </p>
        <p>
          <strong>Accuracy:</strong>{" "}
          <span className={`badge ${aiData.accuracyClass}`}>
            {aiData.accuracy}%
          </span>
        </p>
        <p>
          <strong>Total:</strong> {aiData.total} | <strong>Wins:</strong>{" "}
          {aiData.wins} | <strong>Losses:</strong> {aiData.losses}
        </p>
        <p>
          <strong>Last Result:</strong>{" "}
          <span className={`badge ${lastResult?.isWin ? "green" : "red"}`}>
            {lastResult ? (lastResult.isWin ? "Win" : "Loss") : "..."}
          </span>
        </p>
        <p>
          <strong>Risk:</strong>{" "}
          <span className={`badge risk-${getRiskLevel()}`}>
            {getRiskLevel()}
          </span>
        </p>
        <button className="btn" onClick={handleUndo}>
          Undo
        </button>
        <button className="btn" onClick={handleReset}>
          Reset
        </button>
      </div>

      <div className="history">
        <h3>Last 50 Bets</h3>
        <table>
          <thead>
            <tr>
              <th>اینیمل</th>
              <th>نتیجہ</th>
              <th>ملٹی پلائر</th>
              <th>وقت</th>
            </tr>
          </thead>
          <tbody>
            {history.map((h, i) => (
              <tr key={i}>
                <td>{h.animal}</td>
                <td className={h.isWin ? "green" : "red"}>
                  {h.isWin ? "Win" : "Loss"}
                </td>
                <td>{h.multiplier}x</td>
                <td>{h.time}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="hot-cold">
        <h3>Hot & Cold Animals</h3>
        <div>
          {hotCold.map((h, i) => (
            <div
              key={i}
              className={`animal-stat ${
                i < 3 ? "hot" : i >= hotCold.length - 3 ? "cold" : ""
              }`}
            >
              {h}
            </div>
          ))}
        </div>
      </div>

      <div className="streak-stats">
        <h3>Streak Stats</h3>
        <div>
          {streaks.map((s, i) => (
            <span key={i}>{s}</span>
          ))}
        </div>
      </div>
    </div>
  );
}