// src/components/StatsDisplay.jsx
import React from "react";

const StatsDisplay = ({ stats }) => {
  const {
    totalBets,
    totalWins,
    totalLosses,
    winStreak,
    lossStreak,
    smartness,
    accuracy,
    fishChance,
    riskLevel,
  } = stats;

  return (
    <div className="stats-panel">
      <h3>📊 Game Stats</h3>
      <div className="stat-item">Total Bets: {totalBets}</div>
      <div className="stat-item">Wins: ✅ {totalWins}</div>
      <div className="stat-item">Losses: ❌ {totalLosses}</div>
      <div className="stat-item">Win Streak: 🔥 {winStreak}</div>
      <div className="stat-item">Loss Streak: 🧊 {lossStreak}</div>
      <div className="stat-item">Smartness: 🧠 {smartness}%</div>
      <div className="stat-item">Accuracy: 🎯 {accuracy}%</div>
      <div className="stat-item">Fish Chance: 🐟 {fishChance}%</div>
      <div className="stat-item">Risk Level: ⚠️ {riskLevel}</div>
    </div>
  );
};

export default StatsDisplay;