import React, { useState } from "react";

const AnimalIcon = ({ name, emoji, size = 32 }) => {
  const [imageError, setImageError] = useState(false);
  const src = `icons/${name.toLowerCase()}.png`;

  return imageError ? (
    <span style={{ fontSize: size }}>{emoji}</span>
  ) : (
    <img
      src={src}
      alt={name}
      width={size}
      height={size}
      onError={() => setImageError(true)}
    />
  );
};

export default AnimalIcon;