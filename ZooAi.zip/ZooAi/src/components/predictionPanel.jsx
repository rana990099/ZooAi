// src/components/PredictionPanel.jsx
import React from "react";
import AnimalIcon from "./AnimalIcon";

const PredictionPanel = ({ topPredictions = [] }) => {
  return (
    <div className="prediction-panel">
      <h3>Top Predictions</h3>
      <div className="prediction-grid">
        {topPredictions.map((pred, index) => (
          <div key={index} className="prediction-item">
            <AnimalIcon animal={pred.animal} size={40} />
            <div className="prediction-rank">#{index + 1}</div>
            {pred.confidence !== undefined && (
              <div className="confidence">
                {(pred.confidence * 100).toFixed(1)}%
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default PredictionPanel;