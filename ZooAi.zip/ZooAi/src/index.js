import React from "react";
import ReactDOM from "react-dom";
import ZooAIApp from "./ZooAIApp";

const loadTensorFlow = () => {
  return new Promise((resolve, reject) => {
    if (window.tf) return resolve();
    const script = document.createElement("script");
    script.src = "/tf.min.js";
    script.onload = () => resolve();
    script.onerror = () => reject("TensorFlow load failed");
    document.head.appendChild(script);
  });
};

loadTensorFlow()
  .then(() => {
    console.log("✅ TensorFlow.js loaded");
    ReactDOM.render(<ZooAIApp />, document.getElementById("root"));
  })
  .catch((err) => {
    console.error("❌ TensorFlow Error:", err);
    alert("TensorFlow.js failed to load.");
  });

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/service-worker.js")
      .then(() => console.log("✅ Service Worker Registered"))
      .catch((err) => console.log("❌ SW registration failed:", err));
  });
});