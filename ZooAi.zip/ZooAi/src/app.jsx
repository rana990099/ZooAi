import React, { useEffect } from "react";
import ZooGame from "./components/ZooGame";

export default function App() {
  useEffect(() => {
    document.title = "Rana Waqar Zoo AI 🧠";
  }, []);

  return (
    <main>
      <h2>Rana Waqar Zoo AI 🧠</h2>
      <ZooGame />
    </main>
  );
}